const jwt = require("jsonwebtoken");
const JWT_SECRET = "123"; // Must match the secret in login.js

function authenticateToken(req, res, next) {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) {
    return res.status(401).json({ message: "Access denied. No token provided." });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      console.log("JWT verification error:", err.message);
      return res.status(403).json({ message: "Invalid or expired token" });
    }

    console.log("✅ Authenticated user:", user); // Debug log
    req.user = user; // attaches { user_id, username, role }
    next();
  });
}

module.exports = authenticateToken;
