// client/src/Pages/Admin/AdminAdjustments.jsx
import React, { useEffect, useMemo, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import AdminNavbar from "./AdminNavbar";

const toInt = (v, d = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? Number(n) : d;
};

export default function AdminAdjustments() {
  const navigate = useNavigate();
  const token = localStorage.getItem("token");
  const headers = useMemo(
    () => ({ Authorization: `Bearer ${token}` }),
    [token]
  );

  const [notes, setNotes] = useState([]);
  const [itemsByNote, setItemsByNote] = useState({});
  const [expanded, setExpanded] = useState({}); // note_id -> bool
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  // filters
  const [dateRange, setDateRange] = useState({ start: "", end: "" });
  const [reasons, setReasons] = useState([]);
  const [products, setProducts] = useState([]);
  const [suppliers, setSuppliers] = useState([]);

  const [reasonId, setReasonId] = useState("");
  const [productId, setProductId] = useState("");
  const [supplierId, setSupplierId] = useState("");
  const [status, setStatus] = useState("");
  const [sourceType, setSourceType] = useState("");

  const [viewMode, setViewMode] = useState("table"); // default TABLE

  const safeLogout = () => {
    alert("Session expired. Please log in again.");
    localStorage.removeItem("token");
    navigate("/");
  };

  const fetchDropdowns = async () => {
    try {
      const [reasonRes, productRes, supplierRes] = await Promise.all([
        axios.get("/api/adjustments/reasons", { headers }),
        axios.get("/api/products/list", { headers }),
        axios.get("/api/suppliers/list", { headers }),
      ]);

      setReasons(Array.isArray(reasonRes.data) ? reasonRes.data : []);
      setProducts(Array.isArray(productRes.data) ? productRes.data : []);
      setSuppliers(Array.isArray(supplierRes.data) ? supplierRes.data : []);
    } catch (err) {
      console.error("Failed to load adjustment dropdowns:", err);
      if (err.response?.status === 401 || err.response?.status === 403) {
        safeLogout();
      }
    }
  };

  const fetchNotes = async () => {
    setLoading(true);
    try {
      const params = {};
      if (dateRange.start && dateRange.end) {
        params.start = dateRange.start;
        params.end = dateRange.end;
      }
      if (reasonId) params.reason_id = reasonId;
      if (productId) params.product_id = productId;
      if (supplierId) params.supplier_id = supplierId;
      if (status) params.status = status;
      if (sourceType) params.source_type = sourceType;

      const res = await axios.get("/api/admin/adjustments", {
        headers,
        params,
      });

      const raw = Array.isArray(res.data) ? res.data : [];

      // 🔴 Frontend filter: never show drafts even if backend sends them
      const cleaned = raw.filter(
        (n) => String(n.status || "").toUpperCase() !== "DRAFT"
      );

      setNotes(cleaned);
      setMessage("");
    } catch (err) {
      console.error("Failed to load admin adjustment notes:", err);
      if (err.response?.status === 401 || err.response?.status === 403) {
        safeLogout();
      } else {
        setMessage("❌ Failed to load adjustment notes.");
      }
    } finally {
      setLoading(false);
    }
  };

  const fetchItems = async (noteId) => {
    if (itemsByNote[noteId]) return; // cache
    try {
      // keep using admin endpoint; it already returns allocations
      const res = await axios.get(`/api/admin/adjustments/${noteId}/items`, {
        headers,
      });
      const list = Array.isArray(res.data) ? res.data : [];
      setItemsByNote((m) => ({ ...m, [noteId]: list }));
    } catch (err) {
      console.error("Failed to load adjustment items:", err);
      setItemsByNote((m) => ({ ...m, [noteId]: [] }));
    }
  };

  const toggleExpand = async (noteId) => {
    setExpanded((e) => ({ ...e, [noteId]: !e[noteId] }));
    if (!itemsByNote[noteId]) {
      await fetchItems(noteId);
    }
  };

  useEffect(() => {
    fetchDropdowns();
    fetchNotes();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---------- Item header + row ----------
  const ItemHeader = () => (
    <div className="grid grid-cols-[1.4fr_3fr_1fr_2fr_2.2fr] gap-3 py-2 border-b text-base font-semibold text-gray-700">
      <div>Code</div>
      <div>Product</div>
      <div>Pack</div>
      <div>Change</div>
      <div>Allocations (batches)</div>
    </div>
  );

  const ItemRow = ({ it }) => {
    const pack = Math.max(1, toInt(it.pack_size, 1));

    // 🔢 compute net change from allocations if possible
    const allocNet = (it.allocations || []).reduce(
      (sum, a) => sum + toInt(a.pieces_delta, 0),
      0
    );

    const fallbackNet =
      toInt(it.net_pcs, 0) ||
      (toInt(it.delta_boxes, 0) * pack + toInt(it.delta_items, 0));

    const net = allocNet !== 0 ? allocNet : fallbackNet;

    // derive boxes/items from net, handling negative properly
    let boxes = 0;
    let items = 0;
    if (net >= 0) {
      boxes = Math.floor(net / pack);
      items = net - boxes * pack;
    } else {
      // e.g. net = -13, pack = 10  => -2 boxes, +7 items (overall -13)
      boxes = Math.ceil(net / pack); // e.g. -2
      items = net - boxes * pack; // rest
    }

    const signLabel =
      net > 0 ? `+${net} pcs (increase)` : net < 0 ? `${net} pcs (decrease)` : "0 pcs";

    return (
      <div className="grid grid-cols-[1.4fr_3fr_1fr_2fr_2.2fr] gap-3 py-2 border-b text-base">
        <div className="font-mono text-sm text-gray-700">
          {it.product_code || "-"}
        </div>
        <div className="font-medium truncate">
          {it.product_name}
          {it.expiry_date && (
            <span className="block text-xs text-gray-500">
              Exp: {new Date(it.expiry_date).toLocaleDateString()}
            </span>
          )}
        </div>
        <div>{pack}</div>
        <div>
          <div className="font-semibold">{signLabel}</div>
          <div className="text-xs text-gray-500">
            Boxes: {boxes} | Items: {items}
          </div>
        </div>
        <div className="text-sm text-gray-700 space-y-1">
          {(it.allocations || []).length === 0 && (
            <span className="text-gray-400">No batch allocations</span>
          )}
          {(it.allocations || []).map((al) => (
            <div key={al.allocation_id}>
              batch #{al.batch_id} – {al.pieces_delta > 0 ? "+" : ""}
              {al.pieces_delta} pcs{" "}
              <span className="text-gray-500">
                ({al.batch_source_type} {al.batch_source_id})
              </span>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <>
      <AdminNavbar />

      <div className="max-w-7xl mx-auto mt-8 px-4 md:px-6">
        <div className="bg-white rounded-2xl shadow-md p-6 md:p-10 border border-gray-200">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
            <div className="flex items-center gap-3">
              <span className="text-4xl">🛠️</span>
              <div>
                <h1 className="text-3xl font-semibold text-gray-900 tracking-tight">
                  Adjustment Notes (Admin)
                </h1>
                <p className="text-gray-500 text-sm mt-1">
                  All adjustment notes from all users, with reasons and batch-level
                  changes.
                </p>
              </div>
            </div>

            <button
              onClick={() =>
                setViewMode((mode) => (mode === "table" ? "cards" : "table"))
              }
              className="border border-gray-300 px-5 py-3 rounded-xl hover:bg-gray-50 text-base"
            >
              {viewMode === "table" ? "Card View" : "Table View"}
            </button>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-3 mb-6 items-end">
            {/* Dates */}
            <div>
              <label className="block text-sm text-gray-600 mb-1">
                From date
              </label>
              <input
                type="date"
                value={dateRange.start}
                onChange={(e) =>
                  setDateRange({ ...dateRange, start: e.target.value })
                }
                className="border border-gray-300 px-3 py-2 rounded-xl text-base bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-sm text-gray-600 mb-1">
                To date
              </label>
              <input
                type="date"
                value={dateRange.end}
                onChange={(e) =>
                  setDateRange({ ...dateRange, end: e.target.value })
                }
                className="border border-gray-300 px-3 py-2 rounded-xl text-base bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Reason */}
            <div>
              <label className="block text-sm text-gray-600 mb-1">
                Reason
              </label>
              <select
                value={reasonId}
                onChange={(e) => setReasonId(e.target.value)}
                className="border border-gray-300 px-3 py-2 rounded-xl text-base min-w-[220px] bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">All reasons</option>
                {reasons.map((r) => (
                  <option key={r.reason_id} value={r.reason_id}>
                    {r.display_name}
                  </option>
                ))}
              </select>
            </div>

            {/* Product */}
            <div>
              <label className="block text-sm text-gray-600 mb-1">
                Product
              </label>
              <select
                value={productId}
                onChange={(e) => setProductId(e.target.value)}
                className="border border-gray-300 px-3 py-2 rounded-xl text-base min-w-[260px] bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">All products</option>
                {products.map((p) => (
                  <option key={p.product_id} value={p.product_id}>
                    {p.product_code
                      ? `${p.product_code} – ${p.product_name}`
                      : p.product_name}
                  </option>
                ))}
              </select>
            </div>

            {/* Supplier */}
            <div>
              <label className="block text-sm text-gray-600 mb-1">
                Supplier
              </label>
              <select
                value={supplierId}
                onChange={(e) => setSupplierId(e.target.value)}
                className="border border-gray-300 px-3 py-2 rounded-xl text-base min-w-[220px] bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">All suppliers</option>
                {suppliers.map((s) => (
                  <option key={s.supplier_id} value={s.supplier_id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Status (no DRAFT) */}
            <div>
              <label className="block text-sm text-gray-600 mb-1">
                Status
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value)}
                className="border border-gray-300 px-3 py-2 rounded-xl text-base bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">All</option>
                <option value="PENDING">Pending</option>
                <option value="APPROVED">Approved</option>
                <option value="REJECTED">Rejected</option>
                <option value="POSTED">Posted</option>
              </select>
            </div>

            {/* Source type */}
            <div>
              <label className="block text-sm text-gray-600 mb-1">
                Source
              </label>
              <select
                value={sourceType}
                onChange={(e) => setSourceType(e.target.value)}
                className="border border-gray-300 px-3 py-2 rounded-xl text-base bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">All</option>
                <option value="DIRECT">Direct</option>
                <option value="GRN">GRN</option>
                <option value="ISSUE">Issue note</option>
                <option value="UNLOAD">Unload note</option>
              </select>
            </div>

            {/* Apply */}
            <button
              onClick={fetchNotes}
              className="bg-green-600 text-white px-6 py-2.5 rounded-xl hover:bg-green-700 text-base ml-auto"
            >
              Apply
            </button>
          </div>

          {loading && (
            <div className="text-gray-500 mb-4 text-base">Loading…</div>
          )}

          {/* ============ TABLE VIEW (default) ============ */}
          {viewMode === "table" && (
            <div className="overflow-auto">
              <table className="w-full border border-gray-200 text-base">
                <thead className="bg-gray-100 text-left">
                  <tr>
                    <th className="p-3 border border-gray-200">Note No</th>
                    <th className="p-3 border border-gray-200">Date</th>
                    <th className="p-3 border border-gray-200">Reason</th>
                    <th className="p-3 border border-gray-200">Source</th>
                    <th className="p-3 border border-gray-200">Status</th>
                    <th className="p-3 border border-gray-200">Created By</th>
                    <th className="p-3 border border-gray-200">Items</th>
                    <th className="p-3 border border-gray-200">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {notes.map((n) => {
                    const net = toInt(n.total_delta_pcs, 0);
                    const netLabel =
                      net > 0 ? `+${net} pcs` : net < 0 ? `${net} pcs` : "0 pcs";
                    const sourceLabel = n.source_type
                      ? `${n.source_type}${
                          n.source_ref ? ` (${n.source_ref})` : ""
                        }`
                      : "-";

                    return (
                      <React.Fragment key={n.note_id}>
                        <tr className="odd:bg-white even:bg-gray-50">
                          <td className="p-3 border border-gray-200 font-semibold">
                            {n.note_no}
                          </td>
                          <td className="p-3 border border-gray-200">
                            {n.note_date
                              ? new Date(n.note_date).toLocaleDateString()
                              : "-"}
                          </td>
                          <td className="p-3 border border-gray-200">
                            {n.reason_name || "-"}
                            {n.remark && (
                              <div className="text-xs text-gray-500 mt-1">
                                {n.remark}
                              </div>
                            )}
                          </td>
                          <td className="p-3 border border-gray-200">
                            {sourceLabel}
                          </td>
                          <td className="p-3 border border-gray-200">
                            {n.status}
                          </td>
                          <td className="p-3 border border-gray-200">
                            <div className="font-medium">
                              {n.created_by_full_name}
                            </div>
                            <div className="text-xs text-gray-500">
                              ({n.created_by_username})
                            </div>
                          </td>
                          <td className="p-3 border border-gray-200">
                            {n.item_count}
                          </td>
                          <td className="p-3 border border-gray-200 whitespace-nowrap">
                            <button
                              onClick={() => toggleExpand(n.note_id)}
                              className="border border-gray-300 px-3 py-1.5 rounded-lg hover:bg-gray-100 text-sm"
                            >
                              {expanded[n.note_id] ? "Hide items" : "View items"}
                            </button>
                          </td>
                        </tr>

                        {expanded[n.note_id] && (
                          <tr className="bg-gray-50">
                            <td
                              className="p-0 border-t border-gray-200"
                              colSpan={8}
                            >
                              <div className="p-4">
                                <ItemHeader />
                                {(itemsByNote[n.note_id] || []).map((it) => (
                                  <ItemRow
                                    it={it}
                                    key={`${n.note_id}-${it.item_id}`}
                                  />
                                ))}
                                {!(itemsByNote[n.note_id] || []).length && (
                                  <div className="text-center text-gray-500 py-4 text-sm">
                                    No items
                                  </div>
                                )}
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })}

                  {!notes.length && !loading && (
                    <tr>
                      <td
                        colSpan={8}
                        className="text-center text-gray-500 p-4"
                      >
                        No adjustment notes found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}

          {/* ============ CARDS VIEW ============ */}
          {viewMode === "cards" && (
            <div className="grid 2xl:grid-cols-2 gap-6">
              {notes.map((n) => {
                const net = toInt(n.total_delta_pcs, 0);
                const netLabel =
                  net > 0 ? `+${net} pcs` : net < 0 ? `${net} pcs` : "0 pcs";
                const sourceLabel = n.source_type
                  ? `${n.source_type}${
                      n.source_ref ? ` (${n.source_ref})` : ""
                    }`
                  : "-";

                return (
                  <div
                    key={n.note_id}
                    className="border border-gray-200 rounded-2xl p-6 shadow-sm"
                  >
                    <div className="space-y-1">
                      <div className="text-xl tracking-tight">
                        {n.note_no}
                      </div>
                      <div className="text-gray-700 text-base">
                        <span className="font-medium">Date:</span>{" "}
                        {n.note_date
                          ? new Date(n.note_date).toLocaleDateString()
                          : "-"}
                        <span className="mx-2">•</span>
                        <span className="font-medium">Reason:</span>{" "}
                        {n.reason_name}
                      </div>
                      <div className="text-gray-700 text-base">
                        <span className="font-medium">Source:</span>{" "}
                        {sourceLabel}
                      </div>
                      <div className="text-gray-700 text-base">
                        <span className="font-medium">Status:</span>{" "}
                        {n.status}
                      </div>
                      <div className="text-gray-700 text-base">
                        <span className="font-medium">Created by:</span>{" "}
                        {n.created_by_full_name} ({n.created_by_username})
                      </div>
                      {n.remark && (
                        <div className="text-gray-600 text-sm mt-1 italic">
                          “{n.remark}”
                        </div>
                      )}
                      <div className="text-gray-900 font-semibold text-base mt-2">
                        Net change: {netLabel}
                      </div>
                    </div>

                    <div className="mt-5">
                      <button
                        className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 text-sm"
                        onClick={() => toggleExpand(n.note_id)}
                      >
                        {expanded[n.note_id] ? "Hide items" : "View items"}
                      </button>
                    </div>

                    {expanded[n.note_id] && (
                      <div className="mt-5 rounded-xl border border-gray-200 p-4 bg-gray-50">
                        <ItemHeader />
                        {(itemsByNote[n.note_id] || []).map((it) => (
                          <ItemRow
                            it={it}
                            key={`${n.note_id}-${it.item_id}`}
                          />
                        ))}
                        {!(itemsByNote[n.note_id] || []).length && (
                          <div className="text-center text-gray-500 py-4 text-sm">
                            No items
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}

              {!notes.length && !loading && (
                <div className="text-gray-500 col-span-full text-center text-base">
                  No adjustment notes found.
                </div>
              )}
            </div>
          )}

          {message && (
            <p
              className={`text-center mt-5 text-base font-medium ${
                message.startsWith("✅") ? "text-green-600" : "text-red-600"
              }`}
            >
              {message}
            </p>
          )}

          <p className="text-xs text-gray-500 mt-6">
            Read-only admin view. Use the regular Adjustment page to create or
            modify notes; this page is for audit and review (all users, all reasons).
          </p>
        </div>
      </div>
    </>
  );
}
